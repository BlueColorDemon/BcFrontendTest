﻿[function (require, module, exports) {
    "use strict";
    var ConvType = {
        ORDINARY_GROUP: 0,
        JUMP: 1,
        COMPANY_GROUP: 2,
        SECRETARY: 5,
        FILEHELPER: 6,
        ANNOUNCEMENT: 7,
        CRM_GROUP: 8,
        ENCRYPT_CHAT: 9
    };
    module.exports = ConvType;
}
   , {}]